mkdir ..\tmp
Get-ChildItem -recurse -filter "*-Sword.xml" -file | ForEach-Object  { copy-item $_.fullname ..\tmp\ }
copy-item .\curl.exe ..\tmp\
Push-Location -Path ..\tmp\
Get-ChildItem -filter "*-Sword.xml" -file | ForEach-Object  {
 Write-Host $_
 write-host '---'
 .\curl.exe -k -q -u ifip:halifip https://api.archives-ouvertes.fr/sword/inria -H "Packaging:http://purl.org/net/sword-types/AOfr" -X POST -H "Content-Type:text/xml" --data-binary @$_
 write-host ""
 write-host ""
}
pop-location
Remove-Item -recurse ..\tmp\
